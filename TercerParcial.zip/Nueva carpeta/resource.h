//{{NO_DEPENDENCIES}}
// Archivo de inclusi�n generado de Microsoft Visual C++.
// Usado por TercerParcialProgAv.rc
//
#define IDC_MYICON                      2
#define IDD_TERCERPARCIALPROGAV_DIALOG  102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDI_TERCERPARCIALPROGAV         107
#define IDI_SMALL                       108
#define IDC_TERCERPARCIALPROGAV         109
#define IDR_MAINFRAME                   128
#define IDD_DATOS                       129
#define IDD_EVENTOS                     130
#define IDD_VENTA                       131
#define IDD_COMPRAS                     132
#define IDD_LOGIN                       133
#define IDC_SAVENAME                    1000
#define IDC_SAVEDATE                    1001
#define IDC_SAVETIME                    1002
#define IDC_SAVECOST                    1003
#define IDC_SAVE                        1004
#define IDC_CANCEL                      1005
#define IDC_LISTA                       1007
#define IDC_ELIMINAR                    1011
#define IDC_AGREGAR                     1012
#define IDC_CERRAR                      1013
#define IDC_LISTAVENTA                  1014
#define IDC_SELECT                      1015
#define IDC_EVENTO                      1017
#define IDC_PRECIO                      1018
#define IDC_CANTIDAD                    1019
#define IDC_DESCUENTO                   1020
#define IDC_PLUS                        1021
#define IDC_MINUS                       1022
#define IDC_TOTAL                       1023
#define IDC_BUY                         1024
#define IDC_DELETE                      1026
#define IDC_BACK                        1027
#define IDC_LISTACOMPRAS                1028
#define IDC_CLOSE                       1029
#define IDC_USER                        1030
#define IDC_PASSWORD                    1031
#define IDC_LOGIN                       1033
#define IDC_RETURN                      1034
#define IDC_CALCULATE                   1036
#define IDC_RECOVER                     1037
#define ID_ARCHIVO_INICIARSESION        32771
#define ID_ARCHIVO_EVENTOS              32772
#define ID_ARCHIVO_VENTADEBOLETOS       32773
#define ID_ARCHIVO_MISCOMPRAS           32774
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1038
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif

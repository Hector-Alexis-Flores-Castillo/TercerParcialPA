// TercerParcialProgAv.cpp : Define el punto de entrada de la aplicación.
//

#include "framework.h"
#include "TercerParcialProgAv.h"
#include <CommCtrl.h>
#include <fstream>
using namespace std;

#define MAX_LOADSTRING 100

//Nodos de eventos.
struct nEvento {
    char nombre[100], fecha[100], hora[100];
    float costo;
    int NumEvento;
    nEvento* Sig;
    nEvento* Ant;
};

//Nodos de compras.
struct nCompra {
    char nombre[100], cantidad[100], total[100];
    int NumCompra;
    nCompra* Sig;
    nCompra* Ant;
};

//Variables globales
int CountEvento = 0, CountCompra = 0;
nEvento* inicio = NULL;
nCompra* lista = NULL;
char User[] = { "1234" };
char Pass[] = { "1234" };
bool login = FALSE;
char nombreEventos[] = { "archivoEventos.dat" };
char nombreCompras[] = { "archivoCompras.dat" };

int ItemData;

// Variables globales:
HINSTANCE hInst;                                // instancia actual
WCHAR szTitle[MAX_LOADSTRING];                  // Texto de la barra de título
WCHAR szWindowClass[MAX_LOADSTRING];            // nombre de clase de la ventana principal

// Declaraciones de funciones adelantadas incluidas en este módulo de código:
ATOM                MyRegisterClass(HINSTANCE hInstance);
BOOL                InitInstance(HINSTANCE, int);
LRESULT CALLBACK    WndProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK    About(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK    Login(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK    Eventos(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK    Agregar(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK    Venta(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK    Compras(HWND, UINT, WPARAM, LPARAM);

//Prototipos de función.
void IniciarSesion(HWND);
void ListBoxEventos(nEvento*&, HWND);
void EliminarEvento(nEvento*&, HWND, int);
void NuevoEvento(nEvento*&, HWND);
void ListBoxVenta(nEvento*&, HWND);
void Seleccionar(nEvento*&, HWND, int);
void Calcular(HWND);
void NuevaCompra(nCompra*&, HWND);
void ListBoxCompras(nCompra*&, HWND);
void EliminarCompra(nCompra*&, HWND, int);
void saveEventos(char*);
void readEventos(char*);
void saveCompras(char*);
void readCompras(char*);

int APIENTRY wWinMain(_In_ HINSTANCE hInstance,
                     _In_opt_ HINSTANCE hPrevInstance,
                     _In_ LPWSTR    lpCmdLine,
                     _In_ int       nCmdShow)
{
    UNREFERENCED_PARAMETER(hPrevInstance);
    UNREFERENCED_PARAMETER(lpCmdLine);

    // TODO: Colocar código aquí.

    // Inicializar cadenas globales
    LoadStringW(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
    LoadStringW(hInstance, IDC_TERCERPARCIALPROGAV, szWindowClass, MAX_LOADSTRING);
    MyRegisterClass(hInstance);

    // Realizar la inicialización de la aplicación:
    if (!InitInstance (hInstance, nCmdShow))
    {
        return FALSE;
    }

    HACCEL hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_TERCERPARCIALPROGAV));

    readEventos(nombreEventos);
    readCompras(nombreCompras);
    
    MSG msg;

    // Bucle principal de mensajes:
    while (GetMessage(&msg, nullptr, 0, 0))
    {
        if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg))
        {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }

    saveEventos(nombreEventos);
    saveCompras(nombreCompras);

    return (int) msg.wParam;
}



//
//  FUNCIÓN: MyRegisterClass()
//
//  PROPÓSITO: Registra la clase de ventana.
//
ATOM MyRegisterClass(HINSTANCE hInstance)
{
    WNDCLASSEXW wcex;

    wcex.cbSize = sizeof(WNDCLASSEX);

    wcex.style          = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc    = WndProc;
    wcex.cbClsExtra     = 0;
    wcex.cbWndExtra     = 0;
    wcex.hInstance      = hInstance;
    wcex.hIcon          = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_TERCERPARCIALPROGAV));
    wcex.hCursor        = LoadCursor(nullptr, IDC_ARROW);
    wcex.hbrBackground  = (HBRUSH)(COLOR_WINDOW+1);
    wcex.lpszMenuName   = MAKEINTRESOURCEW(IDC_TERCERPARCIALPROGAV);
    wcex.lpszClassName  = szWindowClass;
    wcex.hIconSm        = LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));

    return RegisterClassExW(&wcex);
}

//
//   FUNCIÓN: InitInstance(HINSTANCE, int)
//
//   PROPÓSITO: Guarda el identificador de instancia y crea la ventana principal
//
//   COMENTARIOS:
//
//        En esta función, se guarda el identificador de instancia en una variable común y
//        se crea y muestra la ventana principal del programa.
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
   hInst = hInstance; // Almacenar identificador de instancia en una variable global

   HWND hWnd = CreateWindowW(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
      CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, nullptr, nullptr, hInstance, nullptr);

   if (!hWnd)
   {
      return FALSE;
   }

   ShowWindow(hWnd, nCmdShow);
   UpdateWindow(hWnd);

   return TRUE;
}

//
//  FUNCIÓN: WndProc(HWND, UINT, WPARAM, LPARAM)
//
//  PROPÓSITO: Procesa mensajes de la ventana principal.
//
//  WM_COMMAND  - procesar el menú de aplicaciones
//  WM_PAINT    - Pintar la ventana principal
//  WM_DESTROY  - publicar un mensaje de salida y volver
//
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
    case WM_COMMAND:
        {
            int wmId = LOWORD(wParam);
            // Analizar las selecciones de menú:
            switch (wmId)
            {
            case IDM_ABOUT:
                DialogBox(hInst, MAKEINTRESOURCE(IDD_ABOUTBOX), hWnd, About);
                break;
            case ID_ARCHIVO_EVENTOS:
                if (login == FALSE) {
                    MessageBox(hWnd, "Debe iniciar sesion.", "Aviso", MB_ICONERROR);
                }
                if (login == TRUE) {
                    DialogBox(hInst, MAKEINTRESOURCE(IDD_EVENTOS), hWnd, Eventos);
                }
                break;
            case ID_ARCHIVO_VENTADEBOLETOS:
                if (login == FALSE) {
                    MessageBox(hWnd, "Debe iniciar sesion.", "Aviso", MB_ICONERROR);
                }
                if (login == TRUE) {
                    DialogBox(hInst, MAKEINTRESOURCE(IDD_VENTA), hWnd, Venta);
                }
                break;
            case ID_ARCHIVO_MISCOMPRAS:
                if (login == FALSE) {
                    MessageBox(hWnd, "Debe iniciar sesion.", "Aviso", MB_ICONERROR);
                }
                if (login == TRUE) {
                    DialogBox(hInst, MAKEINTRESOURCE(IDD_COMPRAS), hWnd, Compras);
                }
                break;
            case ID_ARCHIVO_INICIARSESION:
                DialogBox(hInst, MAKEINTRESOURCE(IDD_LOGIN), hWnd, Login);
                break;
            case IDM_EXIT:
                DestroyWindow(hWnd);
                break;
            default:
                return DefWindowProc(hWnd, message, wParam, lParam);
            }
        }
        break;
    case WM_PAINT:
        {
            PAINTSTRUCT ps;
            HDC hdc = BeginPaint(hWnd, &ps);
            // TODO: Agregar cualquier código de dibujo que use hDC aquí...
            EndPaint(hWnd, &ps);
        }
        break;
    case WM_DESTROY:
        PostQuitMessage(0);
        break;
    default:
        return DefWindowProc(hWnd, message, wParam, lParam);
    }
    return 0;
}

// Controlador de mensajes del cuadro Acerca de.
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    UNREFERENCED_PARAMETER(lParam);
    switch (message)
    {
    case WM_INITDIALOG:
        return (INT_PTR)TRUE;

    case WM_COMMAND:
        if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
        {
            EndDialog(hDlg, LOWORD(wParam));
            return (INT_PTR)TRUE;
        }
        break;
    }
    return (INT_PTR)FALSE;
}

INT_PTR CALLBACK Login(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    UNREFERENCED_PARAMETER(lParam);
    switch (message)
    {
    case WM_INITDIALOG:
        return (INT_PTR)TRUE;

    case WM_COMMAND:
        if (LOWORD(wParam) == IDC_RETURN)
        {
            EndDialog(hDlg, LOWORD(wParam));
            return (INT_PTR)TRUE;
        }
        if (LOWORD(wParam) == IDC_RECOVER)
        {
            SendDlgItemMessage(hDlg, IDC_USER, WM_SETTEXT, NULL, (LPARAM)"1234");
            SendDlgItemMessage(hDlg, IDC_PASSWORD, WM_SETTEXT, NULL, (LPARAM)"1234");
            return (INT_PTR)TRUE;
        }
        if (LOWORD(wParam) == IDC_LOGIN)
        {
            IniciarSesion(hDlg);
            if (login == FALSE) {
                MessageBox(hDlg, "Clave o contrasena invalidos.", "Aviso", MB_ICONERROR);
            }
            if (login == TRUE) {
                MessageBox(hDlg, "Bienvenido", "Aviso", MB_OK);
                EndDialog(hDlg, LOWORD(wParam));
            }
            return (INT_PTR)TRUE;
        }
        break;
    }
    return (INT_PTR)FALSE;
}

INT_PTR CALLBACK Eventos(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    UNREFERENCED_PARAMETER(lParam);
    switch (message)
    {
    case WM_INITDIALOG:
        ListBoxEventos(inicio, hDlg);
        return (INT_PTR)TRUE;

    case WM_COMMAND:
        if (LOWORD(wParam) == IDC_CERRAR)
        {
            EndDialog(hDlg, LOWORD(wParam));
            return (INT_PTR)TRUE;
        }
        if (LOWORD(wParam) == IDC_AGREGAR)
        {
            DialogBox(hInst, MAKEINTRESOURCE(IDD_DATOS), hDlg, Agregar);
            SendDlgItemMessage(hDlg, IDC_LISTA, LB_RESETCONTENT, 0, 0);
            ListBoxEventos(inicio, hDlg);
            return (INT_PTR)TRUE;
        }
        if (LOWORD(wParam) == IDC_ELIMINAR)
        {
            int ListPos = SendDlgItemMessage(hDlg, IDC_LISTA, LB_GETCURSEL, 0, 0);
            ItemData = SendDlgItemMessage(hDlg, IDC_LISTA, LB_GETITEMDATA, ListPos, NULL);
            if (ListPos != -1) {
                EliminarEvento(inicio, hDlg, ItemData);
                SendDlgItemMessage(hDlg, IDC_LISTA, LB_RESETCONTENT, 0, 0);
                ListBoxEventos(inicio, hDlg);
            }
            return (INT_PTR)TRUE;
        }
        break;
    }
    return (INT_PTR)FALSE;
}

INT_PTR CALLBACK Agregar(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    UNREFERENCED_PARAMETER(lParam);
    switch (message)
    {
    case WM_INITDIALOG:
        return (INT_PTR)TRUE;

    case WM_COMMAND:
        if (LOWORD(wParam) == IDC_CANCEL)
        {
            EndDialog(hDlg, LOWORD(wParam));
            return (INT_PTR)TRUE;
        }
        if (LOWORD(wParam) == IDC_SAVE)
        {
            NuevoEvento(inicio, hDlg);
            EndDialog(hDlg, LOWORD(wParam));
            return (INT_PTR)TRUE;
        }
        break;
    }
    return (INT_PTR)FALSE;
}

INT_PTR CALLBACK Venta(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    UNREFERENCED_PARAMETER(lParam);
    switch (message)
    {
    case WM_INITDIALOG:      
        //Agregar datos.
        SendDlgItemMessage(hDlg, IDC_DESCUENTO, CB_ADDSTRING, NULL, (LPARAM)"Ticket 2x1");
        SendDlgItemMessage(hDlg, IDC_DESCUENTO, CB_ADDSTRING, NULL, (LPARAM)"10% de descuento");
        SendDlgItemMessage(hDlg, IDC_DESCUENTO, CB_ADDSTRING, NULL, (LPARAM)"Sin descuento");
        SendDlgItemMessage(hDlg, IDC_CANTIDAD, WM_SETTEXT, NULL, (LPARAM)"1");
        ListBoxVenta(inicio, hDlg);
        return (INT_PTR)TRUE;

    case WM_COMMAND:
        if (LOWORD(wParam) == IDC_CLOSE)
        {
            EndDialog(hDlg, LOWORD(wParam));
            return (INT_PTR)TRUE;
        }
        if (LOWORD(wParam) == IDC_SELECT)
        {
            int ListPos = SendDlgItemMessage(hDlg, IDC_LISTAVENTA, LB_GETCURSEL, 0, 0);
            ItemData = SendDlgItemMessage(hDlg, IDC_LISTAVENTA, LB_GETITEMDATA, ListPos, NULL);
            if (ListPos != -1) {
                SendDlgItemMessage(hDlg, IDC_TOTAL, WM_SETTEXT, NULL, (LPARAM)"");
                Seleccionar(inicio, hDlg, ItemData);
            }
            return (INT_PTR)TRUE;
        }
        if (LOWORD(wParam) == IDC_PLUS)
        {
            //Handlers.
            HWND hCant = GetDlgItem(hDlg, IDC_CANTIDAD);
            //Auxiliares.
            char buffer[50];
            int num, Length;

            //Obtener cantidad.
            Length = GetWindowTextLength(hCant);
            GetWindowText(hCant, buffer, ++Length);
            num = atoi(buffer);

            //Imprimir nuevo.
            num++;
            sprintf_s(buffer, "%d", num);
            SendDlgItemMessage(hDlg, IDC_CANTIDAD, WM_SETTEXT, NULL, (LPARAM)buffer);

            return (INT_PTR)TRUE;
        }
        if (LOWORD(wParam) == IDC_MINUS)
        {
            //Handlers.
            HWND hCant = GetDlgItem(hDlg, IDC_CANTIDAD);
            //Auxiliares.
            char buffer[50];
            int num, Length;

            //Obtener cantidad.
            Length = GetWindowTextLength(hCant);
            GetWindowText(hCant, buffer, ++Length);
            num = atoi(buffer);

            //Imprimir nuevo.
            if (num > 1) {
                num--;
                sprintf_s(buffer, "%d", num);
                SendDlgItemMessage(hDlg, IDC_CANTIDAD, WM_SETTEXT, NULL, (LPARAM)buffer);
            }

            return (INT_PTR)TRUE;
        }
        if (LOWORD(wParam) == IDC_CALCULATE)
        {
            Calcular(hDlg);
            return (INT_PTR)TRUE;
        }
        if (LOWORD(wParam) == IDC_BUY)
        {
            //Comprobar
            HWND hName = GetDlgItem(hDlg, IDC_EVENTO);
            int Length;
            char nombre[100];
            Length = GetWindowTextLength(hName);
            GetWindowText(hName, nombre, ++Length);
            if (strcmp(nombre, "") != 0) {
                NuevaCompra(lista, hDlg);
            }
            //reset
            SendDlgItemMessage(hDlg, IDC_EVENTO, WM_SETTEXT, NULL, (LPARAM)"");
            SendDlgItemMessage(hDlg, IDC_PRECIO, WM_SETTEXT, NULL, (LPARAM)"");
            SendDlgItemMessage(hDlg, IDC_CANTIDAD, WM_SETTEXT, NULL, (LPARAM)"1");
            SendDlgItemMessage(hDlg, IDC_DESCUENTO, CB_SETCURSEL, -1, NULL);
            SendDlgItemMessage(hDlg, IDC_TOTAL, WM_SETTEXT, NULL, (LPARAM)"");
            return (INT_PTR)TRUE;
        }
        break;
    }
    return (INT_PTR)FALSE;
}

INT_PTR CALLBACK Compras(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    UNREFERENCED_PARAMETER(lParam);
    switch (message)
    {
    case WM_INITDIALOG:
        ListBoxCompras(lista, hDlg);
        return (INT_PTR)TRUE;

    case WM_COMMAND:
        if (LOWORD(wParam) == IDC_BACK)
        {
            EndDialog(hDlg, LOWORD(wParam));
            return (INT_PTR)TRUE;
        }
        if (LOWORD(wParam) == IDC_DELETE)
        {
            int ListPos = SendDlgItemMessage(hDlg, IDC_LISTACOMPRAS, LB_GETCURSEL, 0, 0);
            ItemData = SendDlgItemMessage(hDlg, IDC_LISTACOMPRAS, LB_GETITEMDATA, ListPos, NULL);
            if (ListPos != -1) {
                EliminarCompra(lista, hDlg, ItemData);
                SendDlgItemMessage(hDlg, IDC_LISTACOMPRAS, LB_RESETCONTENT, 0, 0);
                ListBoxCompras(lista, hDlg);
            }
            return (INT_PTR)TRUE;
        }
        break;
    }
    return (INT_PTR)FALSE;
}

//Esta funcion se usa en la pantalla de Iniciar Sesion.
void IniciarSesion(HWND hwnd) {
    //Handlers.
    HWND hClave = GetDlgItem(hwnd, IDC_USER);
    HWND hPassword = GetDlgItem(hwnd, IDC_PASSWORD);

    //Auxiliares.
    int Length;
    char loginclave[100], loginpassword[100];

    //Leer datos introducidos.
    Length = GetWindowTextLength(hClave);
    GetWindowText(hClave, loginclave, ++Length);
    Length = GetWindowTextLength(hPassword);
    GetWindowText(hPassword, loginpassword, ++Length);


    //Comprobar datos.
    if (strcmp(loginclave, User) == 0 && strcmp(loginpassword, Pass) == 0) {
        login = TRUE;
    }
}

void ListBoxEventos(nEvento*& inicio, HWND hwnd) {
    nEvento* aux = inicio;
    if (inicio == NULL) {
        return;
    }

    //Imprimir cada nodo en la listbox.
    int pos = 0;
    while (aux != NULL) {
        //Auxiliares.
        char item[100];
        char costo[50];
        sprintf_s(costo, "%.2f", aux->costo);
        
        strcpy_s(item, aux->fecha);
        strcat_s(item, " | ");
        strcat_s(item, aux->hora);
        strcat_s(item, ": ");
        strcat_s(item, aux->nombre);
        strcat_s(item, " - $");
        strcat_s(item, costo);

        //(Cambiar IDs de Listbox).
        SendDlgItemMessage(hwnd, IDC_LISTA, LB_ADDSTRING, NULL, (LPARAM)item);
        SendDlgItemMessage(hwnd, IDC_LISTA, LB_SETITEMDATA, pos, (LPARAM)aux->NumEvento);
        aux = aux->Sig;
        pos++;
    }
}

void ListBoxVenta(nEvento*& inicio, HWND hwnd) {
    nEvento* aux = inicio;
    if (inicio == NULL) {
        return;
    }

    //Imprimir cada nodo en la listbox.
    int pos = 0;
    while (aux != NULL) {
        //Auxiliares.
        char item[100];
        char costo[50];
        sprintf_s(costo, "%.2f", aux->costo);

        strcpy_s(item, aux->fecha);
        strcat_s(item, " | ");
        strcat_s(item, aux->hora);
        strcat_s(item, ": ");
        strcat_s(item, aux->nombre);
        strcat_s(item, " - $");
        strcat_s(item, costo);

        //(Cambiar IDs de Listbox).
        SendDlgItemMessage(hwnd, IDC_LISTAVENTA, LB_ADDSTRING, NULL, (LPARAM)item);
        SendDlgItemMessage(hwnd, IDC_LISTAVENTA, LB_SETITEMDATA, pos, (LPARAM)aux->NumEvento);
        aux = aux->Sig;
        pos++;
    }
}

void EliminarEvento(nEvento*& inicio, HWND hwnd, int NumEvento) {
    //Buscar nodo.
    nEvento* aux = inicio;
    if (inicio == NULL) {
        return;
    }
    while (aux->NumEvento != NumEvento && aux != NULL) {
        aux = aux->Sig;
    }
    if (aux == NULL) {
        return;
    }

    //Revisar si se va a eliminar el primer nodo.
    if (aux == inicio) {
        inicio = aux->Sig;
    }
    else if (aux->Sig == NULL) {
        nEvento* auxant = aux->Ant;
        auxant->Sig = NULL;
    }
    else {
        //Crear auxiliares.
        nEvento* auxsig = aux->Sig;
        nEvento* auxant = aux->Ant;

        //Conectar auxiliares.
        auxsig->Ant = auxant;
        auxant->Sig = auxsig;
    }

    //Borrar nodo.
    delete aux;
}

void NuevoEvento(nEvento*& inicio, HWND hwnd) {
    //Handlers (cambiar IDs).
    HWND hFecha = GetDlgItem(hwnd, IDC_SAVEDATE);
    HWND hHora = GetDlgItem(hwnd, IDC_SAVETIME);
    HWND hName = GetDlgItem(hwnd, IDC_SAVENAME);
    HWND hCosto = GetDlgItem(hwnd, IDC_SAVECOST);

    //Crear nodo y enviar al final.
    nEvento* final = inicio;
    nEvento* nuevo = new nEvento();
    while (final != NULL && final->Sig != NULL) {
        final = final->Sig;
    }
    if (final != NULL) {
        final->Sig = nuevo;
    }
    else {
        inicio = nuevo;
    }
    nuevo->Ant = final;

    //Auxiliares.
    int Length;
    char costoEvento[50];

    //Guardar datos en nodo.
    Length = GetWindowTextLength(hFecha);
    GetWindowText(hFecha, nuevo->fecha, ++Length);
    Length = GetWindowTextLength(hHora);
    GetWindowText(hHora, nuevo->hora, ++Length);
    Length = GetWindowTextLength(hName);
    GetWindowText(hName, nuevo->nombre, ++Length);
    Length = GetWindowTextLength(hCosto);
    GetWindowText(hCosto, costoEvento, ++Length);
    nuevo->costo = atof(costoEvento);

    //Asignar número de evento único.
    nuevo->NumEvento = CountEvento;
    CountEvento++;
}

void Seleccionar(nEvento*& inicio, HWND hwnd, int NumEvento) {
    //Buscar nodo.
    nEvento* aux = inicio;
    if (inicio == NULL) {
        return;
    }
    while (aux->NumEvento != NumEvento && aux != NULL) {
        aux = aux->Sig;
    }
    if (aux == NULL) {
        return;
    }
    
    char costo[50];
    sprintf_s(costo, "%.2f", aux->costo);

    //Imprimir datos en edit control.
    SendDlgItemMessage(hwnd, IDC_EVENTO, WM_SETTEXT, NULL, (LPARAM)aux->nombre);
    SendDlgItemMessage(hwnd, IDC_PRECIO, WM_SETTEXT, NULL, (LPARAM)costo);
}

void Calcular(HWND hwnd) {
    //Handlers.
    HWND hCost = GetDlgItem(hwnd, IDC_PRECIO);
    HWND hCant = GetDlgItem(hwnd, IDC_CANTIDAD);

    //Auxiliares.
    char buffer[50];
    int Length, cant, combo;
    float costo, total = 0;

    //Leer datos.
    Length = GetWindowTextLength(hCost);
    GetWindowText(hCost, buffer, ++Length);
    costo = atof(buffer);
    Length = GetWindowTextLength(hCant);
    GetWindowText(hCant, buffer, ++Length);
    cant = atoi(buffer);
    combo = SendDlgItemMessage(hwnd, IDC_DESCUENTO, CB_GETCURSEL, 0, 0);
    
    //calcular descuentos
    if (combo == -1 || combo == 2) {
        total = costo * cant;
    }
    if (combo == 0 && cant > 1) {
        cant = cant - 1;
        total = costo * cant;
    }
    if (combo == 0 && cant <= 1) {
        total = costo * cant;
    }
    if (combo == 1) {
        total = costo * cant;
        total = total * .9;
    }

    //calcular iva
    total = total * 1.16;

    //Imprimir total
    sprintf_s(buffer, "%.2f", total);
    SendDlgItemMessage(hwnd, IDC_TOTAL, WM_SETTEXT, NULL, (LPARAM)buffer);
}

void NuevaCompra(nCompra*& lista, HWND hwnd) {
    //Handlers (cambiar IDs).
    HWND hName = GetDlgItem(hwnd, IDC_EVENTO);
    HWND hCant = GetDlgItem(hwnd, IDC_CANTIDAD);
    HWND hTotal = GetDlgItem(hwnd, IDC_TOTAL);

    //Crear nodo y enviar al final.
    nCompra* final = lista;
    nCompra* nuevo = new nCompra();
    while (final != NULL && final->Sig != NULL) {
        final = final->Sig;
    }
    if (final != NULL) {
        final->Sig = nuevo;
    }
    else {
        lista = nuevo;
    }
    nuevo->Ant = final;

    //Auxiliares.
    int Length;

    //Guardar datos en nodo.
    Length = GetWindowTextLength(hName);
    GetWindowText(hName, nuevo->nombre, ++Length);
    Length = GetWindowTextLength(hCant);
    GetWindowText(hCant, nuevo->cantidad, ++Length);
    Length = GetWindowTextLength(hTotal);
    GetWindowText(hTotal, nuevo->total, ++Length);

    //Asignar número de compra único.
    nuevo->NumCompra = CountCompra;
    CountCompra++;
    MessageBox(hwnd, "Compra realizada", "Aviso", MB_OK);
}

void ListBoxCompras(nCompra*& lista, HWND hwnd) {
    nCompra* aux = lista;
    if (lista == NULL) {
        return;
    }

    //Imprimir cada nodo en la listbox.
    int pos = 0;
    while (aux != NULL) {
        //Auxiliares.
        char item[100];

        strcpy_s(item, "[");
        strcat_s(item, aux->cantidad);
        strcat_s(item, "] ");
        strcat_s(item, aux->nombre);
        strcat_s(item, " - $");
        strcat_s(item, aux->total);

        //(Cambiar IDs de Listbox).
        SendDlgItemMessage(hwnd, IDC_LISTACOMPRAS, LB_ADDSTRING, NULL, (LPARAM)item);
        SendDlgItemMessage(hwnd, IDC_LISTACOMPRAS, LB_SETITEMDATA, pos, (LPARAM)aux->NumCompra);
        aux = aux->Sig;
        pos++;
    }
}

void EliminarCompra(nCompra*& lista, HWND hwnd, int NumCompra) {
    //Buscar nodo.
    nCompra* aux = lista;
    if (lista == NULL) {
        return;
    }
    while (aux->NumCompra != NumCompra && aux != NULL) {
        aux = aux->Sig;
    }
    if (aux == NULL) {
        return;
    }

    //Revisar si se va a eliminar el primer nodo.
    if (aux == lista) {
        lista = aux->Sig;
    }
    else if (aux->Sig == NULL) {
        nCompra* auxant = aux->Ant;
        auxant->Sig = NULL;
    }
    else {
        //Crear auxiliares.
        nCompra* auxsig = aux->Sig;
        nCompra* auxant = aux->Ant;

        //Conectar auxiliares.
        auxsig->Ant = auxant;
        auxant->Sig = auxsig;
    }

    //Borrar nodo.
    delete aux;
}

void saveEventos(char* archivo) {
    ofstream file;
    file.open(archivo, ios::trunc | ios::binary);
    if (file.is_open())
    {
        nEvento* aux = inicio;
        while (aux != NULL)
        {
            file.write((char*)aux, sizeof(nEvento));

            aux = aux->Sig;
        }
        file.close();
    }
}

void readEventos(char* archivo) {
    nEvento* aux = 0;
    nEvento* ultimo = 0;
    nEvento* nuevo = 0;
    ifstream file;
    file.open(archivo, ios::binary);
    if (file.is_open())
    {
        nuevo = new nEvento;
        file.read((char*)nuevo, sizeof(nEvento));
        while (!file.eof())
        {
            aux = new nEvento;
            aux = nuevo;

            aux->Ant = 0;
            aux->Sig = 0;
            if (inicio == 0) {
                inicio = aux;
            }
            else {
                ultimo->Sig = aux;
                aux->Ant = ultimo;
            }
            ultimo = aux;

            nuevo = new nEvento;
            file.read((char*)nuevo, sizeof(nEvento));
        }
        file.close();
    }
}

void saveCompras(char* archivo) {
    ofstream file;
    file.open(archivo, ios::trunc | ios::binary);
    if (file.is_open())
    {
        nCompra* aux = lista;
        while (aux != NULL)
        {
            file.write((char*)aux, sizeof(nCompra));

            aux = aux->Sig;
        }
        file.close();
    }
}

void readCompras(char* archivo) {
    nCompra* aux = 0;
    nCompra* ultimo = 0;
    nCompra* nuevo = 0;
    ifstream file;
    file.open(archivo, ios::binary);
    if (file.is_open())
    {
        nuevo = new nCompra;
        file.read((char*)nuevo, sizeof(nCompra));
        while (!file.eof())
        {
            aux = new nCompra;
            aux = nuevo;

            aux->Ant = 0;
            aux->Sig = 0;
            if (lista == 0) {
                lista = aux;
            }
            else {
                ultimo->Sig = aux;
                aux->Ant = ultimo;
            }
            ultimo = aux;

            nuevo = new nCompra;
            file.read((char*)nuevo, sizeof(nCompra));
        }
        file.close();
    }
}